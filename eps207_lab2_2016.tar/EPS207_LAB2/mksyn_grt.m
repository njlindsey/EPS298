close all;
clear all;
%%Program to compute radiation pattern coefficients and sum the two
%%fundamental fault Green's functions to compute a synthetic seismogram
%%This program is coded for use with the GRT code

azimuth=321.6;
strike=324.0;
dip=89.0;
rake=-180.0;
moment=1.26e23;
risetime=1.0;
tstart=20.;
nzyear=1993;
nzjday=223;
nzhour=23;
nzmin=33;
nzsec=4;
nzmsec=100;

rho=2.67;


%%Don't modify below this line

theta=azimuth-strike;
theta=theta*pi/180;
rake=rake*pi/180;
dip=dip*pi/180;
moment=moment/1e20;
factor=4*pi*rho;

A4=cos(2*theta)*cos(rake)*sin(dip)-0.5*sin(2*theta)*sin(rake)*sin(2*dip);
A5=-1*sin(theta)*cos(rake)*cos(dip)-cos(theta)*sin(rake)*cos(2*dip);

%%Read the GRT sac files
[tss, hd] = rdSac('synth.tss.sac');
dt=hd(1);
[tds, hd] = rdSac('synth.tds.sac');

%%Create Synthetic
syn=moment./factor.*(A4.*tss + A5.*tds);

%%Create source time function
time=[0:dt:risetime*3];
src=time.*exp(-time./(risetime/4));
src=src./trapz(src);

%%convolve source time function
a=conv(syn,src);
syn2=a(1:length(syn)-1);

time=[0:1:length(syn2)-1].*dt;
plot(time,syn2);

%%Creat SAC files
N=length(syn2);
MYJH_hd = newSacHeader(N,dt,tstart);
MYJH_hd(71)=nzyear;
MYJH_hd(72)=nzjday;
MYJH_hd(73)=nzhour;
MYJH_hd(74)=nzmin;
MYJH_hd(75)=nzsec;
MYJH_hd(76)=nzmsec;
MYJH_sacfile = 'synthetic.sac';
wtSac(MYJH_sacfile,MYJH_hd,syn2);




